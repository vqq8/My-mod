package com.example.renderutilitiz;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public class RenderUtilitizHandler {
    private static final double MAX_RANGE = 6.0;
    private static final double MAX_FOV = 45.0;
    private static final float AIM_SPEED = 0.35F;
    private static final long AIM_COOLDOWN_MS = 100;
    private static long lastAimTime = 0;

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!RenderUtilitizMod.isEnabled()) return;
            if (client.player == null || client.world == null) return;
            if (client.options.attackKey.isPressed()) return;

            long now = System.currentTimeMillis();
            if (now - lastAimTime < AIM_COOLDOWN_MS) return;
            lastAimTime = now;

            Entity target = findBestTarget(client);
            if (target != null) {
                smoothLookAt(client, target);
            }
        });
    }

    private static Entity findBestTarget(MinecraftClient client) {
        Entity bestTarget = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity entity : client.world.getEntities()) {
            if (entity == client.player) continue;
            if (!(entity instanceof LivingEntity)) continue;
            if (entity.isSpectator() || !entity.isAlive()) continue;
            if (client.player.distanceTo(entity) > MAX_RANGE) continue;

            double fov = getAngleToEntity(client, entity);
            if (fov > MAX_FOV) continue;

            double distance = client.player.distanceTo(entity);
            double score = distance * 0.7 + fov * 0.3;
            if (score < bestScore) {
                bestScore = score;
                bestTarget = entity;
            }
        }
        return bestTarget;
    }

    private static double getAngleToEntity(MinecraftClient client, Entity entity) {
        Vec3d cameraVec = client.player.getRotationVec(1.0F);
        Vec3d toEntity = entity.getBoundingBox().getCenter()
                .subtract(client.player.getEyePos())
                .normalize();
        return Math.toDegrees(Math.acos(
                Math.max(-1.0, Math.min(1.0, cameraVec.dotProduct(toEntity)))
        ));
    }

    private static void smoothLookAt(MinecraftClient client, Entity target) {
        Vec3d targetPos = target.getBoundingBox().getCenter();
        Vec3d playerEye = client.player.getEyePos();
        double deltaX = targetPos.x - playerEye.x;
        double deltaY = targetPos.y - playerEye.y;
        double deltaZ = targetPos.z - playerEye.z;
        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);

        float targetYaw   = (float) Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0F;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(deltaY, horizontalDistance));

        float newYaw   = client.player.getYaw()   + (targetYaw   - client.player.getYaw())   * AIM_SPEED;
        float newPitch = client.player.getPitch()  + (targetPitch - client.player.getPitch()) * AIM_SPEED;

        client.player.setYaw(newYaw);
        client.player.setPitch(newPitch);
    }
}
