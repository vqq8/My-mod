# RenderUtilitiz Mod

A Fabric client-side mod that provides smooth aim assist against mobs.

## Requirements
- Minecraft 1.21.4
- Fabric Loader 0.16.10+
- Fabric API

## Building

1. Install JDK 21
2. Run: `./gradlew build`
3. Find the `.jar` in `build/libs/`

## Usage

| Key | Action |
|-----|--------|
| `Y` | Toggle RenderUtilitiz on/off |

- Aim assist **only activates while holding left-click (attack)**
- Works on mobs within **6 blocks**, within **45° FOV**
- Targets the best-scored entity (blend of distance + angle)
- A hotbar message confirms enabled/disabled state

## Notes on fabric.mod.json version field

The `"26.1.2"` in your original fabric.mod.json refers to the **Fabric loader build number**, 
not the Minecraft version. This project targets **Minecraft 1.21.4** which corresponds 
to Fabric loader ~0.16.x. Update `gradle.properties` if you need a different MC version.
